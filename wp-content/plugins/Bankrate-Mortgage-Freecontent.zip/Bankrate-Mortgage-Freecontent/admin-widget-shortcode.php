<div class="short_code">
	<div id="btnForOther2"  style="float:none; color:#004276; float:right;  font-family:Arial; font-size:12px;" >
		<div id="btnCopyOther2" style="cursor:pointer;" >
			<a href=""  style="cursor:pointer"><img src="<?php echo WP_PLUGIN_URL.'/Bankrate-Mortgage-Freecontent'; ?>/images/arrow.jpg" />&nbsp;<?php echo _e('Click to copy code'); ?></a>
		</div>
	</div>

	<div id="btnForIE2" style="display: none;color:#004276; float:right;  font-family:Arial; font-size:12px;">
		<div id="btnCopyIE2">
			<a href="javascript:onclick =ClipBoard();">
			<img src="<?php echo WP_PLUGIN_URL.'/Bankrate-Mortgage-Freecontent'; ?>/images/arrow.jpg" />&nbsp;<?php echo _e('Click to copy code'); ?>
			</a>
		</div>
	</div>
		<span class="shortcode_left"><?php echo _e('SHORT CODE'); ?></span>
</div>

	<div class="textbox_area">
		<textarea style="width:385px;height:55px;" name="sourcehtml" id="sourcehtml">
		[Bankratemortgagecalculator color="color1"  fonttype="Arial"  size="275"]
		</textarea>
	</div>
	<div class="textbox_below"><?php echo _e('If your browser does not allow automatic copy, then '); ?><a href="javascript:selectAll()"><?php echo _e('select all'); ?></a>, <?php echo _e('and <br /> copy and paste the code from the window above.'); ?></div>
	
