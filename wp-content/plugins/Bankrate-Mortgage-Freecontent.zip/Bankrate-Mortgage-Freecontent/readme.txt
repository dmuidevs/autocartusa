===Bankrate.com Wordpress Plugin ===
Tags: mortgage calculator,wordpress,wordpress mortgage calculator,mortgage calculator for wordpress
Requires at least: 3.1
Tested up to: 3.2
Stable tag: 0.4.1

== Description ==
This Bankrate.com plugin offers the industry leading mortgage calculator for use on your web site. Color scheme and size of widget are configurable.

== Installation ==
	1. Upload the `Bankrate-Mortgage-Freecontent` folder to the `wp-content/plugins/` directory
	2. Activate the wordpress SEO plugin through the 'Plugins' menu is Wordpress
	3. Configure the plugin by going the 'SEO' menu that appears in your admin menu

== Frequently Asked Questions ==

== Screenshots==

== Changelog ==

== Other Notes==

